# 🤖 ML Model Comparison Dashboard

B.Tech AI & Data Science · MBM University, Jodhpur · 2026

## 🚀 Deploy Steps (Do this once — takes 10 minutes)

### Step 1 — Create GitHub Account
- Go to https://github.com and sign up (free)

### Step 2 — Create a New Repository
- Click the **+** button → New repository
- Name it: `ml-dashboard`
- Keep it **Public**
- Click **Create repository**

### Step 3 — Upload Your Files
- Click **Upload files**
- Upload these 3 files:
  - `app.py`
  - `requirements.txt`
  - `.github/workflows/deploy.yml`
- Click **Commit changes**

### Step 4 — Deploy on Streamlit Cloud
- Go to https://streamlit.io/cloud and sign in with GitHub
- Click **New app**
- Select your repo: `ml-dashboard`
- Main file: `app.py`
- Click **Deploy**
- Wait 2-3 minutes → you get a live link like:
  `https://yourname-ml-dashboard.streamlit.app`

### Step 5 — Share the link
- Open on your laptop or phone
- Show your sir the live running app!

---
## 📁 Project Structure
```
ml-dashboard/
├── app.py                        # Main Streamlit app
├── requirements.txt              # Python dependencies
└── .github/
    └── workflows/
        └── deploy.yml            # GitHub Actions CI/CD
```
